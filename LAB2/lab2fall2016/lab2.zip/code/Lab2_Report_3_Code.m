xn = 1:10;
Xk = myMatrixDFT(xn,10);
xk = fft(xn,10)

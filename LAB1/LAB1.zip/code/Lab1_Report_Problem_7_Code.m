load speechsig
soundsc(x)